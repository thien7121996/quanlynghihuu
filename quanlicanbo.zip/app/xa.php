<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class xa extends Model
{
    protected $table = 'xa';
}
